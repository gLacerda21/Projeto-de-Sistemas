package model;

public class Subtracao implements Operacao {
  public int calcular(int a, int b) {
    return a - b;
  }
}
