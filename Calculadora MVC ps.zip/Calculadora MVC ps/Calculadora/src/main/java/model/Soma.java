package model;

public class Soma implements Operacao {
  public int calcular(int a, int b) {
    return a + b;
  }
}
