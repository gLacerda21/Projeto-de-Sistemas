package model;

public interface Operacao {
  int calcular(int a, int b);
}
